# Informe de entrega - SpringEduManager

## 1. Identificación

- **Proyecto:** SpringEduManager
- **Módulo:** Módulo 6 - Desarrollo de aplicaciones JEE con Spring Framework
- **Propósito:** administrar estudiantes, cursos, prácticas y evaluaciones en una plataforma web interna.

## 2. Solución desarrollada

SpringEduManager aplica una arquitectura en capas. Los controladores atienden solicitudes web y REST; los servicios concentran la lógica de negocio; los repositorios abstraen el acceso a H2; y las entidades representan el dominio educativo. La interfaz fue construida con Thymeleaf y se protege mediante autenticación y autorización basada en roles.

## 3. Cumplimiento de la pauta

| Requisito | Implementación | Ubicación |
|---|---|---|
| Maven | Proyecto y ciclo de vida con Maven Wrapper | `pom.xml`, `mvnw`, `mvnw.cmd` |
| Spring Boot y MVC | Controladores, vistas y rutas GET/POST | `controller/`, `templates/` |
| Entidades Estudiante y Curso | Entidades JPA con validaciones | `model/Estudiante.java`, `model/Curso.java` |
| Formularios HTML | Alta y edición de estudiantes y cursos | `templates/estudiantes/`, `templates/cursos/` |
| JPA y repositorios | Interfaces que extienden `JpaRepository` | `repository/` |
| Capa de servicio | Servicios anotados con `@Service` | `service/` |
| Base de datos | H2 persistente en archivo local | `application.properties` |
| Seguridad | Login, logout y roles ADMIN/USER | `config/SecurityConfig.java` |
| Carga de cursos restringida | Vistas, rutas y métodos protegidos para ADMIN | `CursoController`, `SecurityConfig` |
| API REST | CRUD JSON con GET, POST, PUT y DELETE | `*RestController.java` |
| Cliente externo | Colección importable en Postman | `postman/` |
| Evidencias | Código fuente, documentación y colección de pruebas | raíz del repositorio y `postman/` |

## 4. Roles y reglas de acceso

- **ADMIN:** consulta la aplicación y administra cursos. Puede abrir la consola H2 y ejecutar operaciones de escritura sobre `/api/cursos`.
- **USER:** consulta cursos y el panel; puede utilizar la gestión de estudiantes y consultar los endpoints autenticados.
- Todo acceso requiere autenticación, excepto la página de login y los recursos estáticos.

## 5. Modelo de datos

- `Estudiante`: identificador, nombre y correo único.
- `Curso`: identificador, nombre, descripción y duración en horas.
- `Practica`: título, fecha de entrega y curso asociado.
- `Evaluacion`: nombre, nota, estudiante y curso asociados.

## 6. Prueba sugerida

1. Ejecutar `./mvnw clean package`.
2. Ejecutar `./mvnw spring-boot:run`.
3. Ingresar como `estudiante` y comprobar la consulta de cursos.
4. Intentar abrir `/cursos/nuevo`; el acceso debe ser denegado.
5. Cerrar sesión e ingresar como `admin`.
6. Crear y editar un curso desde la interfaz.
7. Importar la colección Postman y ejecutar las operaciones CRUD.
8. Confirmar que las respuestas REST están en formato JSON.

## 7. Conclusión

La solución satisface los cinco hitos del proyecto: gestión Maven, patrón MVC, persistencia JPA, control de acceso y servicios REST. Su organización modular permite incorporar posteriormente inscripciones, usuarios persistentes, JWT u otros sistemas del campus.
