package cl.bootcamp.springedumanager.controller;

import cl.bootcamp.springedumanager.model.Curso;
import cl.bootcamp.springedumanager.service.CursoService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

@Controller
@RequestMapping("/cursos")
public class CursoController {
    private final CursoService service;
    public CursoController(CursoService service) { this.service = service; }
    @GetMapping String listar(Model model) { model.addAttribute("cursos", service.listar()); return "cursos/lista"; }
    @GetMapping("/nuevo") String nuevo(Model model) { model.addAttribute("curso", new Curso()); return "cursos/formulario"; }
    @GetMapping("/{id}/editar") String editar(@PathVariable Long id, Model model) { model.addAttribute("curso", service.buscar(id)); return "cursos/formulario"; }
    @PostMapping("/guardar") @PreAuthorize("hasRole('ADMIN')") String guardar(@Valid @ModelAttribute Curso curso, BindingResult result) { if (result.hasErrors()) return "cursos/formulario"; service.guardar(curso); return "redirect:/cursos"; }
    @PostMapping("/{id}/eliminar") @PreAuthorize("hasRole('ADMIN')") String eliminar(@PathVariable Long id) { service.eliminar(id); return "redirect:/cursos"; }
}
