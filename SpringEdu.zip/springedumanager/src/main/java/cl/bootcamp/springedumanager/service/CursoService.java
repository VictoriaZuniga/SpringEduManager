package cl.bootcamp.springedumanager.service;

import cl.bootcamp.springedumanager.model.Curso;
import cl.bootcamp.springedumanager.repository.CursoRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CursoService {
    private final CursoRepository repository;
    public CursoService(CursoRepository repository) { this.repository = repository; }
    public List<Curso> listar() { return repository.findAll(); }
    public Curso buscar(Long id) { return repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Curso no encontrado: " + id)); }
    public Curso guardar(Curso curso) { return repository.save(curso); }
    public void eliminar(Long id) { repository.deleteById(id); }
}
