package cl.bootcamp.springedumanager.controller;

import cl.bootcamp.springedumanager.model.Estudiante;
import cl.bootcamp.springedumanager.service.EstudianteService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/estudiantes")
public class EstudianteController {
    private final EstudianteService service;
    public EstudianteController(EstudianteService service) { this.service = service; }
    @GetMapping String listar(Model model) { model.addAttribute("estudiantes", service.listar()); return "estudiantes/lista"; }
    @GetMapping("/nuevo") String nuevo(Model model) { model.addAttribute("estudiante", new Estudiante()); return "estudiantes/formulario"; }
    @GetMapping("/{id}/editar") String editar(@PathVariable Long id, Model model) { model.addAttribute("estudiante", service.buscar(id)); return "estudiantes/formulario"; }
    @PostMapping("/guardar") String guardar(@Valid @ModelAttribute Estudiante estudiante, BindingResult result) { if (result.hasErrors()) return "estudiantes/formulario"; service.guardar(estudiante); return "redirect:/estudiantes"; }
    @PostMapping("/{id}/eliminar") String eliminar(@PathVariable Long id) { service.eliminar(id); return "redirect:/estudiantes"; }
}
