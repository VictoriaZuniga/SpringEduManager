package cl.bootcamp.springedumanager.controller;

import cl.bootcamp.springedumanager.repository.EvaluacionRepository;
import cl.bootcamp.springedumanager.repository.PracticaRepository;
import cl.bootcamp.springedumanager.service.CursoService;
import cl.bootcamp.springedumanager.service.EstudianteService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {
    private final EstudianteService estudiantes;
    private final CursoService cursos;
    private final PracticaRepository practicas;
    private final EvaluacionRepository evaluaciones;
    public WebController(EstudianteService estudiantes, CursoService cursos, PracticaRepository practicas, EvaluacionRepository evaluaciones) {
        this.estudiantes = estudiantes; this.cursos = cursos; this.practicas = practicas; this.evaluaciones = evaluaciones;
    }
    @GetMapping("/login") String login() { return "login"; }
    @GetMapping("/") String inicio(Model model) {
        model.addAttribute("totalEstudiantes", estudiantes.listar().size());
        model.addAttribute("totalCursos", cursos.listar().size());
        model.addAttribute("totalPracticas", practicas.count());
        model.addAttribute("totalEvaluaciones", evaluaciones.count());
        model.addAttribute("practicas", practicas.findAll());
        model.addAttribute("evaluaciones", evaluaciones.findAll());
        return "index";
    }
}
