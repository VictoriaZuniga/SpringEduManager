package cl.bootcamp.springedumanager.controller;

import cl.bootcamp.springedumanager.model.Curso;
import cl.bootcamp.springedumanager.service.CursoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/cursos")
public class CursoRestController {
    private final CursoService service;
    public CursoRestController(CursoService service) { this.service = service; }
    @GetMapping public List<Curso> listar() { return service.listar(); }
    @GetMapping("/{id}") public Curso buscar(@PathVariable Long id) { return service.buscar(id); }
    @PostMapping @PreAuthorize("hasRole('ADMIN')") @ResponseStatus(HttpStatus.CREATED) public Curso crear(@Valid @RequestBody Curso curso) { curso.setId(null); return service.guardar(curso); }
    @PutMapping("/{id}") @PreAuthorize("hasRole('ADMIN')") public Curso actualizar(@PathVariable Long id, @Valid @RequestBody Curso curso) { service.buscar(id); curso.setId(id); return service.guardar(curso); }
    @DeleteMapping("/{id}") @PreAuthorize("hasRole('ADMIN')") @ResponseStatus(HttpStatus.NO_CONTENT) public void eliminar(@PathVariable Long id) { service.eliminar(id); }
}
