package cl.bootcamp.springedumanager.service;

import cl.bootcamp.springedumanager.model.Estudiante;
import cl.bootcamp.springedumanager.repository.EstudianteRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EstudianteService {
    private final EstudianteRepository repository;
    public EstudianteService(EstudianteRepository repository) { this.repository = repository; }
    public List<Estudiante> listar() { return repository.findAll(); }
    public Estudiante buscar(Long id) { return repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Estudiante no encontrado: " + id)); }
    public Estudiante guardar(Estudiante estudiante) { return repository.save(estudiante); }
    public void eliminar(Long id) { repository.deleteById(id); }
}
