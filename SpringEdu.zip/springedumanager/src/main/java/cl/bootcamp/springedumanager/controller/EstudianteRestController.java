package cl.bootcamp.springedumanager.controller;

import cl.bootcamp.springedumanager.model.Estudiante;
import cl.bootcamp.springedumanager.service.EstudianteService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteRestController {
    private final EstudianteService service;
    public EstudianteRestController(EstudianteService service) { this.service = service; }
    @GetMapping public List<Estudiante> listar() { return service.listar(); }
    @GetMapping("/{id}") public Estudiante buscar(@PathVariable Long id) { return service.buscar(id); }
    @PostMapping @ResponseStatus(HttpStatus.CREATED) public Estudiante crear(@Valid @RequestBody Estudiante estudiante) { estudiante.setId(null); return service.guardar(estudiante); }
    @PutMapping("/{id}") public Estudiante actualizar(@PathVariable Long id, @Valid @RequestBody Estudiante estudiante) { service.buscar(id); estudiante.setId(id); return service.guardar(estudiante); }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void eliminar(@PathVariable Long id) { service.eliminar(id); }
}
