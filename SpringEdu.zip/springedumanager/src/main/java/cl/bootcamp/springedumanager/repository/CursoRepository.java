package cl.bootcamp.springedumanager.repository;
import cl.bootcamp.springedumanager.model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CursoRepository extends JpaRepository<Curso, Long> {}
