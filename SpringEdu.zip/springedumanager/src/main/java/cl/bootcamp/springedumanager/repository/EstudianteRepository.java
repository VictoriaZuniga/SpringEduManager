package cl.bootcamp.springedumanager.repository;
import cl.bootcamp.springedumanager.model.Estudiante;
import org.springframework.data.jpa.repository.JpaRepository;
public interface EstudianteRepository extends JpaRepository<Estudiante, Long> {}
