package cl.bootcamp.springedumanager.config;

import cl.bootcamp.springedumanager.model.*;
import cl.bootcamp.springedumanager.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.time.LocalDate;

@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner datosDemo(CursoRepository cursos, EstudianteRepository estudiantes,
            PracticaRepository practicas, EvaluacionRepository evaluaciones) {
        return args -> {
            if (cursos.count() > 0) return;
            Curso java = curso("Java con Spring Boot", "Aplicaciones web empresariales con MVC, JPA y seguridad.", 80);
            Curso datos = curso("Bases de datos", "Modelado relacional, SQL y persistencia de datos.", 48);
            cursos.save(java); cursos.save(datos);
            Estudiante ana = estudiante("Ana Torres", "ana.torres@springedu.cl");
            Estudiante diego = estudiante("Diego Soto", "diego.soto@springedu.cl");
            estudiantes.save(ana); estudiantes.save(diego);
            Practica p = new Practica(); p.setTitulo("CRUD con Spring Data JPA"); p.setFechaEntrega(LocalDate.now().plusDays(7)); p.setCurso(java); practicas.save(p);
            Evaluacion e = new Evaluacion(); e.setNombre("Evaluación módulo 6"); e.setNota(6.5); e.setEstudiante(ana); e.setCurso(java); evaluaciones.save(e);
        };
    }
    private Curso curso(String nombre, String descripcion, int horas) { Curso c = new Curso(); c.setNombre(nombre); c.setDescripcion(descripcion); c.setDuracionHoras(horas); return c; }
    private Estudiante estudiante(String nombre, String email) { Estudiante e = new Estudiante(); e.setNombre(nombre); e.setEmail(email); return e; }
}
