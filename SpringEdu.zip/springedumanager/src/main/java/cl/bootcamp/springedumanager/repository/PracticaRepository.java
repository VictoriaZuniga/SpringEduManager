package cl.bootcamp.springedumanager.repository;
import cl.bootcamp.springedumanager.model.Practica;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PracticaRepository extends JpaRepository<Practica, Long> {}
