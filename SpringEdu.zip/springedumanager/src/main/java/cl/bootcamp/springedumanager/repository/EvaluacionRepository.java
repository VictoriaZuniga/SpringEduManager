package cl.bootcamp.springedumanager.repository;
import cl.bootcamp.springedumanager.model.Evaluacion;
import org.springframework.data.jpa.repository.JpaRepository;
public interface EvaluacionRepository extends JpaRepository<Evaluacion, Long> {}
